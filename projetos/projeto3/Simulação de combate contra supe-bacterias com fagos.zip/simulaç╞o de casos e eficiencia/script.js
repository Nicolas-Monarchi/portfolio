// Dados fictícios estendidos para 50 anos de simulação
const simulationData = {
    efficiency: Array.from({ length: 50 }, (_, i) => 85 + i * 0.3), // Eficiência cresce gradualmente
    years: Array.from({ length: 50 }, (_, i) => 2020 + i), // De 2020 a 2069
    incidence: Array.from({ length: 50 }, (_, i) => 1000 - i * 15), // Casos reduzem gradualmente
};

// Função para inicializar gráficos
function initCharts() {
    // Gráfico de Eficiência
    const efficiencyCtx = document.getElementById('efficiencyChart').getContext('2d');
    new Chart(efficiencyCtx, {
        type: 'line',
        data: {
            labels: simulationData.years,
            datasets: [{
                label: 'Eficiência (%)',
                data: simulationData.efficiency,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderWidth: 2,
                tension: 0.4,
            }],
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
            },
            scales: {
                y: { beginAtZero: true },
            },
        },
    });

    // Gráfico de Incidência
    const incidenceCtx = document.getElementById('incidenceChart').getContext('2d');
    new Chart(incidenceCtx, {
        type: 'bar',
        data: {
            labels: simulationData.years,
            datasets: [{
                label: 'Casos de Superbactérias',
                data: simulationData.incidence,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
            }],
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
            },
            scales: {
                y: { beginAtZero: true },
            },
        },
    });
}

// Função para atualizar o relatório
function updateReport() {
    const summaryElement = document.getElementById('summary');
    const avgEfficiency = (
        simulationData.efficiency.reduce((sum, value) => sum + value, 0) / simulationData.efficiency.length
    ).toFixed(2);

    summaryElement.textContent = `
        A simulação foi estendida para um período de 50 anos (2020 a 2069). Os resultados mostram um aumento contínuo na eficiência dos bacteriófagos, 
        atingindo aproximadamente ${simulationData.efficiency[simulationData.efficiency.length - 1].toFixed(2)}% no último ano. Durante esse período, 
        os casos de superbactérias reduziram de ${simulationData.incidence[0]} para ${
        simulationData.incidence[simulationData.incidence.length - 1]
    }. 
        Essa análise destaca o impacto positivo do uso de bacteriófagos ao longo do tempo, reforçando sua viabilidade como alternativa terapêutica.
    `;
}

// Inicializar tudo quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    updateReport();
});
